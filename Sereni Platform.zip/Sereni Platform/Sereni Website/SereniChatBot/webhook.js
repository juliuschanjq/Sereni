'use strict';

const functions = require('firebase-functions');
const { google } = require('googleapis');
const { WebhookClient } = require('dialogflow-fulfillment');

// Enter your calendar ID below and service account JSON below
const calendarId = "";
const serviceAccount = {
  "type": "service_account",
  "project_id": "seranichat-htlr",
  "private_key_id": "",
  "private_key": "",
  "client_email": "",
  "client_id": "",
  "auth_uri": "https://accounts.google.com/o/oauth2/auth",
  "token_uri": "https://oauth2.googleapis.com/token",
  "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
  "client_x509_cert_url": "",
  "universe_domain": "googleapis.com"
}

// Set up Google Calendar Service account credentials
const serviceAccountAuth = new google.auth.JWT({
  email: serviceAccount.client_email,
  key: serviceAccount.private_key,
  scopes: 'https://www.googleapis.com/auth/calendar'
});

const calendar = google.calendar('v3');
process.env.DEBUG = 'dialogflow:*'; // enables lib debugging statements

const timeZone = 'Asia/Singapore';
const timeZoneOffset = '+08:00';

exports.dialogflowFirebaseFulfillment = functions.https.onRequest((request, response) => {
  const agent = new WebhookClient({ request, response });
  console.log("Parameters", agent.parameters);

  const appointmentType = agent.parameters.appointmentType;
  const name = agent.parameters.name; // Extract the name parameter
  const phoneNumber = agent.parameters['phone-number']; // Extract the phone number parameter
  const email = agent.parameters.email; // Extract the email parameter

  function makeAppointment(agent) {
    // Calculate appointment start and end datetimes (end = +1hr from start)
    const dateTimeStart = new Date(Date.parse(agent.parameters.appointmentDate.split('T')[0] + 'T' + agent.parameters.appointmentTime.split('T')[1].split('+')[0] + timeZoneOffset));
    const dateTimeEnd = new Date(new Date(dateTimeStart).setHours(dateTimeStart.getHours() + 1));
    const appointmentTimeString = dateTimeStart.toLocaleString('en-US', { month: 'long', day: 'numeric', hour: 'numeric', timeZone: timeZone });
    const now = new Date();
    if (dateTimeStart <= now) {
      agent.add("I'm sorry, you can't book an appointment in the past.");
      return; // Exit the function
    }

    // Check the availability of the time, and make an appointment if there is time on the calendar
    return createCalendarEvent(dateTimeStart, dateTimeEnd, appointmentType, name, phoneNumber, email).then(() => {
      agent.add(`Ok, ${name} your appointment for ${appointmentType} has been booked on ${appointmentTimeString}! Looking forward to supporting you on your mental health journey!`);
    }).catch(() => {
      agent.add(`I'm sorry, there are no slots available for ${appointmentTimeString}.`);
    });
  }

  let intentMap = new Map();
  intentMap.set('BookAppointment', makeAppointment);
  agent.handleRequest(intentMap);
});

function createCalendarEvent(dateTimeStart, dateTimeEnd, appointmentType, name, phoneNumber, email) {
  return new Promise((resolve, reject) => {
    calendar.events.insert({
      auth: serviceAccountAuth,
      calendarId: calendarId,
      resource: {
        summary: `Appointment: ${appointmentType}`,
        description: `Name: ${name}, Phone Number: ${phoneNumber}, Email: ${email}`,
        start: { dateTime: dateTimeStart },
        end: { dateTime: dateTimeEnd }
      }
    }, (err, event) => {
      if (err) {
        console.error('Error creating calendar event:', err);
        reject(err);
      }
      resolve(event);
    });
  });
}
