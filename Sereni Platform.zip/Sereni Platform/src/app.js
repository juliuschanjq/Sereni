const contact_us_btn = document.querySelector("#contact-us-btn");
const container = document.querySelector(".container");

contact_us_btn.addEventListener("click", () => {
  container.classList.add("contact-us-mode");
});


