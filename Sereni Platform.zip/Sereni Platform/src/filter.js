function filterResources(category) {
    var cards = document.querySelectorAll('.card');

    if (category === 'all') {
        cards.forEach(function (card) {
            card.style.display = 'block';
        });
    } else {
        cards.forEach(function (card) {
            if (card.getAttribute('data-category').includes(category)) {
                card.style.display = 'block';
            } else {
                card.style.display = 'none';
            }
        });
    }
}
