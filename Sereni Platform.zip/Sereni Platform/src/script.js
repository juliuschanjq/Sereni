import { initializeApp } from "https://www.gstatic.com/firebasejs/10.13.0/firebase-app.js";
import { getDatabase, ref, set } from "https://www.gstatic.com/firebasejs/10.13.0/firebase-database.js";

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "",
  authDomain: "",
  databaseURL: "",
  projectId: "seranichat-htlr",
  storageBucket: "",
  messagingSenderId: "",
  appId: ""
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getDatabase(app);

// Function to format a timestamp into a readable date string
function formatDate(timestamp) {
  const date = new Date(timestamp);
  // Format date and time as 'YYYY-MM-DD HH:mm:ss'
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')} ${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}:${String(date.getSeconds()).padStart(2, '0')}`;
}

// Function to handle form submission
document.getElementById('contactForm').addEventListener('submit', async function(event) {
  event.preventDefault(); // Prevent the default form submission

  // Collect form data
  const name = document.querySelector('input[placeholder="Your Name"]').value;
  const email = document.querySelector('input[placeholder="Your Email"]').value;
  const phone = document.querySelector('input[placeholder="Your Phone Number"]').value;
  const message = document.querySelector('textarea[placeholder="Your Message"]').value;

  // Generate a timestamp and format it
  const timestamp = Date.now();
  const formattedDate = formatDate(timestamp);

  // Create a reference to the "messages" path in your database using the formatted date as the key
  const newMessageRef = ref(db, 'messages/' + formattedDate);

  // Save the form data to the database
  try {
    await set(newMessageRef, {
      name: name,
      email: email,
      phone: phone,
      message: message,
      timestamp: formattedDate // Store the formatted date and time
    });

    // Display the success message
    document.getElementById('successMessage').style.display = 'block';

    // Optionally, clear the form fields
    document.getElementById('contactForm').reset();
  } catch (error) {
    console.error("Error saving data to Firebase: ", error);
    alert("There was an error saving your message. Please try again.");
  }
});
